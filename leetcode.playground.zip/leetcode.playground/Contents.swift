func log10(val: Int) -> Int
{
    var log: Int
    if val > 10000 {log = 4} else
        if val > 1000 {log = 3} else
            if val >= 100 {log = 2} else
                if val > 10 {log = 1} else
                {log=0}
    
    return Int(log)
}

func findClosestElements(_ arr: [Int], _ k: Int, _ x: Int) -> [Int]
{
    var newarr: [Int] = []
    var start: Int
    
    if x > 0 // ограничение спереди
    {
        
        if k > 1 // количество в адеквате
        {
            start = x - (k/2)
            
            k
            x
            arr.count
            
            if (k+1==arr.count)//if the same place for both sides from mid
            {
                for item in 0...k-1
                {
                    newarr.append(arr[item])
                }
            } else
            {
                if (start+k > arr.count-1) // ограничение сзади
                {
                    if ((arr.count-1)-(start+k/2)>1) && arr.count<20
                    {
                        for item in arr.count-k...arr.count-1
                        {
                            newarr.append(arr[item-1])
                        }
                    }else{
                        for item in arr.count-k...arr.count-1
                        {
                            newarr.append(arr[item])
                        }
                    }
                }
                else  //если до зада не достал
                {
                    if (start-1<0)//первый элемент, середина <
                    {
                        start = 0
                        for item in start...start + k-1
                        {
                            newarr.append(arr[item])
                        }
                    }
                    else // Спереди и сзади место есть (Стандарт)
                    {
                        //Уберем тугие бублики
                        var zeros: Int = 1
                        var zerochecker: Bool = true
                        for item in arr[0]...arr.count - 1
                        {
                            if arr[item]==0 && zerochecker == true
                            {
                                if arr[item+1]==arr[item]
                                {
                                    zeros += 1
                                }
                                else {zerochecker = false}
                            }
                        }
                        if zeros>k
                        {
                            start = x + zeros - k
                            for item in start...start-1 + k
                            {
                                newarr.append(arr[item])
                            }
                        }else // no zeros!
                        {
                            var n: Int
                            n=log10(val: (arr.count))
                            if arr.count>20 && (k%2)==1
                            {
                                start+=1
                            }
                            
                            for item in start...start-1 + k
                            {
                                if n > 1
                                {
                                    newarr.append(arr[item+n-1])
                                }else
                                {
                                    newarr.append(arr[item+n-1])
                                }
                            }
                        }
                    }
                    
                }
            }
            
        }else //k =< 1
        {
            newarr.append(x)
        }
        
    } else // x <= 0
    {
        start = 0
        
        if k>0
        {
            for item in start...start + k-1
            {
                newarr.append(arr[item])
            }
        }
        else // k <= 0
        {
            newarr.append(arr[0])
        }
        
    }
    
    return newarr
}

findClosestElements([2,4,5,7,8,8,8,8,11,11,13,13,13,13,14,15,16,16,17,18,18,18,18,18,19,20,20,22,22,24,24,26,28,29,31,32,33,36,36,40,40,43,43,43,44,44,45,47,48,51,51,52,55,55,55,55,56,57,58,58,59,59,59,62,63,63,63,65,65,66,67,69,70,71,73,73,73,74,76,76,76,76,79,83,84,85,86,88,88,89,92,93,94,94,95,97,98,98,98,99],24,77)
